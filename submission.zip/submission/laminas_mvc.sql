-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Feb 05, 2023 at 09:10 PM
-- Server version: 5.7.31
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laminas_mvc`
--

-- --------------------------------------------------------

--
-- Table structure for table `beers`
--

DROP TABLE IF EXISTS `beers`;
CREATE TABLE IF NOT EXISTS `beers` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `brewery_id` int(11) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `cat_id` int(11) UNSIGNED NOT NULL,
  `style_id` int(11) UNSIGNED NOT NULL,
  `abv` float NOT NULL DEFAULT '0',
  `ibu` float NOT NULL DEFAULT '0',
  `srm` int(11) NOT NULL DEFAULT '0',
  `upc` int(11) NOT NULL DEFAULT '0',
  `filepath` varchar(255) DEFAULT NULL,
  `descript` text,
  `add_user` int(11) UNSIGNED DEFAULT NULL,
  `last_mod` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `beers`
--

INSERT INTO `beers` (`id`, `brewery_id`, `name`, `cat_id`, `style_id`, `abv`, `ibu`, `srm`, `upc`, `filepath`, `descript`, `add_user`, `last_mod`) VALUES
(1, 2, 'Beer Test 1', 2, 2, 1, 1, 1, 1, 'bird-3.jpg', 'test 1', 0, '2023-02-06 02:39:01'),
(3, 11, 'Barelegs Brew', 5, 5, 4.3, 3.3, 1, 2, 'bird-2.jpg', 'Barelegs Brew', 0, '2023-02-06 02:39:57');

-- --------------------------------------------------------

--
-- Table structure for table `breweries`
--

DROP TABLE IF EXISTS `breweries`;
CREATE TABLE IF NOT EXISTS `breweries` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf32 NOT NULL,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `breweries`
--

INSERT INTO `breweries` (`id`, `name`, `updated_at`) VALUES
(2, 'Test Brewery One', '2023-02-05 22:02:04'),
(3, 'Abbey Wright Brewing/Valley Inn', '2023-02-06 02:10:29'),
(4, 'Aktienbrauerei Kaufbeuren', '2023-02-06 02:10:46'),
(5, 'American Brewing', '2023-02-06 02:11:16'),
(6, 'Michigan Brewery Company', '2023-02-06 02:11:45'),
(7, 'Ballast Point Brewing', '2023-02-06 02:12:02'),
(8, 'Belhaven Brewery', '2023-02-06 02:12:22'),
(9, 'Belize Brewing', '2023-02-06 02:12:34'),
(10, 'Bella Brewery Inc.', '2023-02-06 02:13:06'),
(11, 'Brasserie du Bouffay', '2023-02-06 02:13:56'),
(12, 'Oakshire Brewery', '2023-02-06 02:14:16'),
(13, 'Hertog Jan', '2023-02-06 02:14:31'),
(14, 'HC Berger Brewing', '2023-02-06 02:14:48'),
(15, 'Escanaba Brewery', '2023-02-06 02:15:12'),
(16, 'Herkimer Pub & Brewery', '2023-02-06 02:15:32'),
(17, 'Hida Takayama Brewing', '2023-02-06 02:15:48');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `updated_at`) VALUES
(2, 'British Ale', '2023-02-05 16:43:17'),
(4, 'Irish Ale', '2023-02-05 18:45:09'),
(5, 'North American Ale', '2023-02-05 18:45:09'),
(6, 'German Ale', '2023-02-05 18:45:09'),
(7, 'Belgian and French Ale', '2023-02-05 18:45:09'),
(8, 'International Ale', '2023-02-05 18:45:09'),
(9, 'German Lager', '2023-02-05 18:45:09'),
(10, 'North American Lager', '2023-02-05 18:45:09'),
(11, 'Other Lager', '2023-02-05 18:45:09'),
(12, 'International Lager', '2023-02-05 18:45:09'),
(13, 'Japanese Style', '2023-02-05 18:45:09');

-- --------------------------------------------------------

--
-- Table structure for table `styles`
--

DROP TABLE IF EXISTS `styles`;
CREATE TABLE IF NOT EXISTS `styles` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `styles`
--

INSERT INTO `styles` (`id`, `name`, `updated_at`) VALUES
(2, 'style 11', '2023-02-05 18:08:40'),
(3, 'Classic English-Style Pale Ale', '2023-02-06 02:08:46'),
(4, 'English-Style India Pale Ale', '2023-02-06 02:08:46'),
(5, 'Ordinary Bitter', '2023-02-06 02:08:46'),
(6, 'Special Bitter or Best Bitter', '2023-02-06 02:08:46'),
(7, 'Extra Special Bitter', '2023-02-06 02:08:46'),
(8, 'English-Style Summer Ale', '2023-02-06 02:08:46'),
(9, 'Scottish-Style Light Ale', '2023-02-06 02:08:46'),
(10, 'Scottish-Style Heavy Ale', '2023-02-06 02:08:46'),
(11, 'Scottish-Style Export Ale', '2023-02-06 02:08:46'),
(12, 'English-Style Pale Mild Ale', '2023-02-06 02:08:46'),
(13, 'English-Style Dark Mild Ale', '2023-02-06 02:08:46'),
(14, 'English-Style Brown Ale', '2023-02-06 02:08:46'),
(15, 'Old Ale', '2023-02-06 02:08:46'),
(16, 'Strong Ale', '2023-02-06 02:08:46'),
(17, 'Scotch Ale', '2023-02-06 02:08:46'),
(18, 'British-Style Imperial Stout', '2023-02-06 02:08:46'),
(19, 'British-Style Barley Wine Ale', '2023-02-06 02:08:46'),
(20, 'Robust Porter', '2023-02-06 02:08:46'),
(21, 'Brown Porter', '2023-02-06 02:08:46'),
(22, 'Sweet Stout', '2023-02-06 02:08:46'),
(23, 'Oatmeal Stout', '2023-02-06 02:08:46'),
(24, 'Irish-Style Red Ale', '2023-02-06 02:08:46'),
(25, 'Classic Irish-Style Dry Stout', '2023-02-06 02:08:46'),
(26, 'Foreign (Export)-Style Stout', '2023-02-06 02:08:46'),
(27, 'Porter', '2023-02-06 02:08:46'),
(28, 'American-Style Pale Ale', '2023-02-06 02:08:46'),
(29, 'Fresh Hop Ale', '2023-02-06 02:08:46'),
(30, 'Pale American-Belgo-Style Ale', '2023-02-06 02:08:46'),
(31, 'Dark American-Belgo-Style Ale', '2023-02-06 02:08:46'),
(32, 'American-Style Strong Pale Ale', '2023-02-06 02:08:46'),
(33, 'American-Style India Pale Ale', '2023-02-06 02:08:46'),
(34, 'Imperial or Double India Pale Ale', '2023-02-06 02:08:46'),
(35, 'American-Style Amber/Red Ale', '2023-02-06 02:08:46'),
(36, 'Imperial or Double Red Ale', '2023-02-06 02:08:46'),
(37, 'American-Style Barley Wine Ale', '2023-02-06 02:08:46');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `updated_at` datetime NOT NULL ON UPDATE CURRENT_TIMESTAMP,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
